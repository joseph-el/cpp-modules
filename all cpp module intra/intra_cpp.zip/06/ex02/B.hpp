# pragma once

# include "Base.hpp"

class B : public Base {};