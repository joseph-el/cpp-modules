# pragma once

# include "Base.hpp"

class A : public Base {};