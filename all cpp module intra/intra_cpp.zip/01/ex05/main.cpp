# include "Harl.hpp"

int main(void)
{
    Harl ret;

    ret.complain("DEBUG");
    ret.complain("ERRddOR");
    ret.complain("INFO");
    ret.complain("ERROR");
    ret.complain("WARNING");
}