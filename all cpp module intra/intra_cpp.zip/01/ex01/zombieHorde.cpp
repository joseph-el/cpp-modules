# include "Zombie.hpp"

void Zombie::set(std::string Name) {
    name = Name;
}

Zombie* zombieHorde( int N, std::string name ){
    Zombie *zombies = new Zombie[N];
    while (N--)
        zombies[N].set(name);
    return (zombies);
}