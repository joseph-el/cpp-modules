# include "IMateriaSource.hpp"

IMateriaSource::~IMateriaSource() {
    // std::cout << "Destructor of IMateriaSource\n";
}