# include "ICharacter.hpp"
# include "AMateria.hpp"

ICharacter::~ICharacter() {
    // std::cout << "ICharacter Destructor\n";
}