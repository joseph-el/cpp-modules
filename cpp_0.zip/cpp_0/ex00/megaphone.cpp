/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   megaphone.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yoel-idr <yoel-idr@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/26 07:53:55 by yoel-idr          #+#    #+#             */
/*   Updated: 2023/04/26 13:27:18 by yoel-idr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <iostream>

# define ERR_MSG std::cout  << "* LOUD AND UNBEARABLE FEEDBACK NOISE *\n"; return (1);

int main(int argc, char **argv)
{
    if (argc == 1)
        {ERR_MSG};
    while (++argv and *argv)
        for (char *ret = *argv; *ret; ret++)
            std::cout << (char)toupper(*ret);
    std::cout << std::endl;
    return (EXIT_SUCCESS);
}