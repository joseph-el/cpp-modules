# include "PmergeMe.hpp"


# include <deque>

typedef std::deque<int> t_pmergeme;

# include <list>

std::list<std::string> split(const std::string &line) 
{
    std::list<std::string> split;

    short end = line.find_first_of(' ');
    short start = 0;


    std::string::iterator it;

    while (end != std::string::npos)
    {
    
        set :
            start = end + 1;
            


    }
}

int main(int argc, char **argv)
{
    t_pmergeme soritng;

    std::strin



    exit(EXIT_SUCCESS);
}